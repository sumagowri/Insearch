package com.example.insearch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Stud_reg extends AppCompatActivity {
    Button register;
    EditText nameW,collegeW,emailW,phoneW,passW,confirmW;
    int user_id;
    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stud_reg);

        queue = Volley.newRequestQueue(this);

        register=findViewById(R.id.register);
        nameW = findViewById(R.id.name);
        collegeW = findViewById(R.id.college);
        emailW = findViewById(R.id.email);
        phoneW = findViewById(R.id.phone);
        passW = findViewById(R.id.pass);
        confirmW = findViewById(R.id.confirmpass);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameW.getText().toString();
                String college = collegeW.getText().toString();
                String email = emailW.getText().toString();
                long phone = Long.parseLong(phoneW.getText().toString());
                String pass = passW.getText().toString();
                String confirm = confirmW.getText().toString();

                validate(name,college,email,phone,pass,confirm);
                Student s = new Student(name,college,email,phone,pass);
                uploadRegisterData(s);
            }
        });
    }
    
    private void validate(String name, String college, String email, float phone, String pass, String confirm){
        if(name.isEmpty()){
            Toast.makeText(this, "Name is empty", Toast.LENGTH_SHORT).show();
        }else if (college.isEmpty()){
            Toast.makeText(this, "College name is too short", Toast.LENGTH_SHORT).show();
        }else if (email.isEmpty()){
            Toast.makeText(this, "College name is too short", Toast.LENGTH_SHORT).show();
        }else if (phone==0){
            Toast.makeText(this, "College name is too short", Toast.LENGTH_SHORT).show();
        }else if (pass.isEmpty()){
            Toast.makeText(this, "College name is too short", Toast.LENGTH_SHORT).show();
        }else if (confirm.isEmpty()){
            Toast.makeText(this, "College name is too short", Toast.LENGTH_SHORT).show();
        }else if(!pass.equals(confirm)){
            Toast.makeText(this, "password needs to be same", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void goToHome(int stud_id){
        user_id=stud_id;
        Intent intent = new Intent(Stud_reg.this, Student_Home.class);
        intent.putExtra("user_id",user_id);
        startActivity(intent);
    }

    private void uploadRegisterData(Student student){
        String url = "https://insearchsystem.000webhostapp.com/php/student_register.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject respObj = new JSONObject(response);
                            boolean res = respObj.getBoolean("status");
                            int stud_id = respObj.getInt("stud_id");
                            if(res){
                                goToHome(stud_id);
                            }else{
                                Toast.makeText(Stud_reg.this, "Already registered", Toast.LENGTH_SHORT).show();
                            }
                        }catch (JSONException e){
                            Toast.makeText(Stud_reg.this, "Try again!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Stud_reg.this, "Try again!!!", Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("stud_name",student.getName());
                params.put("stud_college",student.getColg_name());
                params.put("stud_email",student.getEmail());
                params.put("stud_phone", String.valueOf(student.getPhone()));
                params.put("stud_password",student.getPassword());
                return params;
            }
        };
        queue.add(stringRequest);
    }
}

class Student{
    String name;
    String colg_name;
    String email;
    long phone;
    String password;

    public Student(String name, String colg_name, String email, long phone, String password) {
        this.name = name;
        this.colg_name = colg_name;
        this.email = email;
        this.phone = phone;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getColg_name() {
        return colg_name;
    }

    public String getEmail() {
        return email;
    }

    public long getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setColg_name(String colg_name) {
        this.colg_name = colg_name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}